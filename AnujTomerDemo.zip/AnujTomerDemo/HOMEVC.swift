//
//  HOMEVC.swift
//  AnujTomerDemo
//
//  Created by Mphrx on 02/01/22.
//

import UIKit

class HOMEVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
