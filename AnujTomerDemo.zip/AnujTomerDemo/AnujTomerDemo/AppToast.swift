//
//  AppToast.swift
//  Capsula
//
//  Created by Admin on 23/12/20.
//

import Foundation


//class AppToast{
////
//    static func showMessage(title: String =  "",message:String,completion: (() -> ())? = nil) {
//
//        //AppDelegate.shared.window?.rootViewController{
//        if let rootVC = AppDelegate.shared.window?.rootViewController{
//            var style = ToastStyle()
//            style.messageFont = AppFont.Regular.size(AppFontName.poppins, size: 12)
//            style.messageColor = .white
//            style.messageAlignment = .center
//            style.backgroundColor = #colorLiteral(red: 1, green: 0.4705882353, blue: 0.3176470588, alpha: 1)
//            rootVC.view.makeToast(message, duration: 3.0, position: .bottom,style : style)
//        }
////
////        /// fix it later
////
//////        CRNotifications.showNotification(type: type.value, title: title1, message: message, dismissDelay: 5, completion: { completion})
//    }
//}

