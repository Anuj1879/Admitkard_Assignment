//
//  ViewController.swift
//  AnujTomerDemo
//
//  Created by Mphrx on 01/01/22.
//

import UIKit
import ADCountryPicker

class ViewController: UIViewController{
    
    let picker = ADCountryPicker()
    
    @IBOutlet weak var btnCountryCode : UIButton!
    @IBOutlet weak var btnLogin : UIButton!
    @IBOutlet weak var lblCountryCode : UILabel!
    @IBOutlet weak var txtMobileNumber : UITextField!
    @IBOutlet weak var lblError : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        lblError.text = ""
    }

    @IBAction func btnCountryCode(_ sender: UIButton){
        let picker = ADCountryPicker()
        picker.delegate = self as? ADCountryPickerDelegate
        let pickerNavigationController = UINavigationController(rootViewController: picker)
        self.present(pickerNavigationController, animated: true, completion: nil)
        
        picker.didSelectCountryWithCallingCodeClosure = { name, code, dialCode in
            
            DispatchQueue.main.async {
                self.lblCountryCode.text = dialCode
            }
            self.dismiss(animated: false, completion: nil)
        }
    }
    @IBAction func btnLogin(_ sender: UIButton){
        
        if txtMobileNumber.text == ""{
            lblError.text = "please enter mobile number"
        }else if txtMobileNumber.text?.count != 10{
            lblError.text = "please enter Corrent mobile number"
        }else{
            lblError.text = ""
            let vc = storyboard?.instantiateViewController(withIdentifier: "OTPVC") as! OTPVC
            navigationController?.pushViewController(vc, animated: true)
        }
    }

}


