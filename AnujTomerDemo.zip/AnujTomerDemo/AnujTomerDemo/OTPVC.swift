//
//  OTPVC.swift
//  AnujTomerDemo
//
//  Created by Mphrx on 02/01/22.
//

import UIKit

class OTPVC: UIViewController {
    
    //MARK:- Variables
    var otpCode : String?
    
    //MARK:- Outlets
    @IBOutlet weak var viewOtpPin : GGPinView!
    @IBOutlet weak var lblError : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblError.text = ""
    }

    @IBAction func BtnSubmitPressed(_ sender: UIButton){
        viewOtpPin.getPinText = { text in
            self.otpCode = text
            print(text)
        }
        if otpCode == ""{
            lblError.text = "please enter OTP"
        }else if otpCode == "1234"{
            lblError.text = "please enter valid OTP"
        }else{
            lblError.text = ""
            let vc = storyboard?.instantiateViewController(withIdentifier: "HOMEVC") as! HOMEVC
            navigationController?.pushViewController(vc, animated: true)
        }
        
    }

}
